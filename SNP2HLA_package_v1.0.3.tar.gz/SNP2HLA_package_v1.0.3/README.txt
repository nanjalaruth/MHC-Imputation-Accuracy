#################################################################################################################################
#
# SNP2HLA software package
#
# Author: Sherman Jia (xiaomingjia@gmail.com)
#
#################################################################################################################################

Contents:
Three directories,

1)  SNP2HLA : HLA imputation software

2)  MakeReference : Software used to build a reference dataset for HLA imputation

3)  Pan-Asian : A pre-built reference dataset based on the data of pan-Asian subjects. These are 530 individuals that are all pan-Asian population.

** T1DGC data has been removed as of version 1.0.3 due to individual genotype data issue **


Please refer to README.txt file in each of these directories for detailed explanations.
